#!/bin/bash
# Deva AC Website - Media File Setup Script
# Run this script after extracting the zip to set up your media files.

echo "=============================================="
echo "  Deva AC Website - Media Setup"
echo "=============================================="
echo ""
echo "Please place your media files in this folder structure:"
echo ""
echo "public/"
echo "├── videos/"
echo "│   ├── ac-repair-1.mp4     (AC Repair & Fix video 1)"
echo "│   ├── ac-repair-2.mp4     (AC Repair & Fix video 2)"
echo "│   ├── ac-repair-3.mp4     (AC Repair & Fix video 3)"
echo "│   ├── ac-install-1.mp4    (AC Installation video 1)"
echo "│   ├── ac-install-2.mp4    (AC Installation video 2)"
echo "│   ├── ac-install-3.mp4    (AC Installation video 3)"
echo "│   ├── gas-refill-1.mp4    (Gas Refill & Leak Fix video)"
echo "│   ├── ac-clean-1.mp4      (Deep Cleaning & Service video 1)"
echo "│   ├── ac-clean-2.mp4      (Deep Cleaning & Service video 2)"
echo "│   └── ac-clean-3.mp4      (Deep Cleaning & Service video 3)"
echo "├── gas-refill-2.jpeg      (Gas Refill & Leak Fix image 1)"
echo "└── gas-refill-3.jpeg      (Gas Refill & Leak Fix image 2)"
echo ""
echo "If you have files with different names, rename them to match above."
echo ""

# Create directories
mkdir -p public/videos

echo "✅ Created public/videos/ directory"
echo ""
echo "Now copy your video and image files to the locations above."
echo "After that, run:"
echo "  npm install"
echo "  npx prisma generate"
echo "  npx prisma db push"
echo "  npm run dev"
echo ""
echo "=============================================="
